/** Compatibility switch: keep the official tools exposed instead of replaced. */
import type { Context } from '../../adapter/dsh/types.js';
export declare const name = "dsh-ops-compat";
export declare function apply(ctx: Context): void;
