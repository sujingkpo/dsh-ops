/** Inspect public presentation before publishing a replacement. Inspection is
 * marked by exact context identity and never becomes a provider request. */
import type { AssembleContext, PromptAssembly, SystemPrompt } from './adapter/dsh/types.js';
export declare function isPresentationProbe(context: AssembleContext): boolean;
export declare function inspectPresentation(prompt: Pick<SystemPrompt, 'assemble'>, scope: NonNullable<AssembleContext['scope']>, signal?: AbortSignal): Promise<PromptAssembly>;
export declare function isNativePresentation(prompt: Pick<SystemPrompt, 'assemble'>, scope: NonNullable<AssembleContext['scope']>, signal?: AbortSignal): Promise<boolean>;
export declare function inspectPresentationShared(prompt: Pick<SystemPrompt, 'assemble'>, scope: NonNullable<AssembleContext['scope']>, signature: string, signal?: AbortSignal): Promise<PromptAssembly>;
/** Drop the memo for one Agent (used when its surface is deliberately rebuilt). */
export declare function forgetPresentation(scope: object): void;
