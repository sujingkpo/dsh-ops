import type { RuntimeRemote } from '../settings/runtime-contract.js';
import type { SettingsProps } from './forms.js';
export declare function ShellForm(props: SettingsProps & {
    api: RuntimeRemote;
}): import("react/jsx-runtime").JSX.Element;
