import type { ConfigPageForm, PluginConfigViewProps } from '../adapter/dsh/types.js';
import type { SettingsPathOpView } from '../adapter/dsh/types.js';
import type { Translator } from './locales.js';
export type SettingsProps = PluginConfigViewProps & {
    t: Translator;
};
export declare const strings: (value: unknown) => string[];
export declare const errorText: (value: unknown) => string;
export declare const checked: (values: string[], key: string, enabled: boolean) => string[];
export declare function useEditor<T>(form: ConfigPageForm | undefined, read: (value: Record<string, unknown>) => T, t: Translator): {
    draft: T;
    edit: (value: T) => void;
    dirty: boolean;
    busy: boolean;
    ready: boolean;
    message: string;
    reset: () => void;
    save: (operations: readonly SettingsPathOpView[]) => Promise<void>;
};
export declare function Unavailable({ form, t }: SettingsProps): import("react/jsx-runtime").JSX.Element;
export declare function FormActions({ busy, dirty, valid, reset, message, t }: {
    busy: boolean;
    dirty: boolean;
    valid?: boolean;
    reset(): void;
    message: string;
    t: Translator;
}): import("react/jsx-runtime").JSX.Element;
