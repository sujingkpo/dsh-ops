import type { RuntimeRemote } from '../settings/runtime-contract.js';
import type { Translator } from './locales.js';
export declare function RuntimePanel({ api, t, onSelect, editable }: {
    api: RuntimeRemote;
    t: Translator;
    onSelect(path: string): void;
    editable: boolean;
}): import("react/jsx-runtime").JSX.Element;
