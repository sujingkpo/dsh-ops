import type { SettingsProps } from './forms.js';
export declare function ReplacementForm(props: SettingsProps): import("react/jsx-runtime").JSX.Element;
export declare function DiscoveryForm(props: SettingsProps): import("react/jsx-runtime").JSX.Element;
