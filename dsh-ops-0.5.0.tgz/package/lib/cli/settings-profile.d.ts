import type { CarrierHost } from '../settings/carrier-plan.js';
export declare function loadCarrierHost(anchor: string): Promise<CarrierHost>;
export declare function commandSettingsProfile(options: {
    profileDir?: string;
    hostAnchor?: string;
    home?: string;
    yes?: boolean;
    offline?: boolean;
    dryRun?: boolean;
}): Promise<number>;
