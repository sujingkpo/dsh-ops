import type { AtomicApi, BootApi, ProfileContext } from '../adapter/dsh/types.js';
import type * as Yaml from 'yaml';
import type { EntryOptions } from '../adapter/dsh/types.js';
export declare const CLIENT_BUNDLE = "dsh-ops/lib/profiles/client";
export interface CarrierHost {
    boot: BootApi;
    yaml: typeof Yaml;
    atomic: AtomicApi;
}
export interface CarrierLocation {
    dir: string;
    home: string;
    installAnchor: string;
}
export interface FileChange {
    path: string;
    before?: string;
    after: string;
    mode: number;
}
export interface CarrierPlan {
    files: FileChange[];
    beforeRows: EntryOptions[];
    afterRows: EntryOptions[];
    location: CarrierLocation;
}
export declare function profileContext(location: CarrierLocation): ProfileContext;
export declare function prepareCarrier(host: CarrierHost, location: CarrierLocation): CarrierPlan;
