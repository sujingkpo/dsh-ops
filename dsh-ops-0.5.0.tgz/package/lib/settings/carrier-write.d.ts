import type { CarrierHost, CarrierLocation, CarrierPlan } from './carrier-plan.js';
export declare function applyCarrier(host: CarrierHost, reviewed: CarrierPlan): Promise<string>;
export declare function carrierPreview(host: CarrierHost, location: CarrierLocation): Promise<CarrierPlan>;
